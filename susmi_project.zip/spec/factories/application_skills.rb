FactoryBot.define do
  factory :application_skill do
    application
    skill
  end
end
