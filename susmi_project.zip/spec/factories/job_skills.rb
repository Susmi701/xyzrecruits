FactoryBot.define do
  factory :job_skill do
    job
    skill
  end
end
