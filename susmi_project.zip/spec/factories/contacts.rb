FactoryBot.define do
  factory :contact do
    address {"address"}
    phone {"123456789"}
    email {"user@gmail.com"}
    website {"http://example.com"}
  end
end
