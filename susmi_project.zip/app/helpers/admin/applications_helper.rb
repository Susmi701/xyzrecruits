module Admin::ApplicationsHelper
end
