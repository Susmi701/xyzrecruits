module Admin::SkillsHelper
end
