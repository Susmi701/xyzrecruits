module Admin::InquiriesHelper
end
