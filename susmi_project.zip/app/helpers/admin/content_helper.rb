module Admin::ContentHelper
end
