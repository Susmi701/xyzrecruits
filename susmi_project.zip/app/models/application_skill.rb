class ApplicationSkill < ApplicationRecord
  belongs_to :application
  belongs_to :skill
end
