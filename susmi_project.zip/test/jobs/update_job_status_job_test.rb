require "test_helper"

class UpdateJobStatusJobTest < ActiveJob::TestCase
  # test "the truth" do
  #   assert true
  # end
end
