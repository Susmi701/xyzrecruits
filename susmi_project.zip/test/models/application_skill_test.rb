require "test_helper"

class ApplicationSkillTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
