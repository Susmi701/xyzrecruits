require "test_helper"

class PageContentTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
